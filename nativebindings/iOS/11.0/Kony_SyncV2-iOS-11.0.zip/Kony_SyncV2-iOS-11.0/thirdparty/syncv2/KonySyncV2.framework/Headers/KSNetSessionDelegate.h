//
//  KSNetSessionDelegate.h
//  SyncNetworkUtil
//
//  Created by Girish Lingarajappa Haniyamballi on 28/11/16.
//  Copyright © 2016 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Delegate instance which receives delegate calls once service request is resumed/started.
 */
@interface KSNetSessionDelegate : NSObject <NSURLSessionDelegate,
        NSURLSessionTaskDelegate,
        NSURLSessionDataDelegate,
        NSURLSessionDownloadDelegate,
        NSURLSessionStreamDelegate>

@end
